//
//  UploadViewController.swift
//  NewsApp
//
//  Created by APPLE on 14/12/22.
//

import UIKit
import BSImagePicker
import Photos

class UploadViewController: UIViewController, UIImagePickerControllerDelegate {
    
    @IBOutlet weak var selectImg: UIButton!
    @IBOutlet weak var selctedImg: UIImageView!
    @IBOutlet weak var uploadServer: UIButton!
    
    //  let imagePicker = UIImagePickerController()
    
    let imagePicker = ImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.title = "Multiple Files"
        
    }
    // MARK: - Button events...
    @IBAction func selectImgBtnActn(_ sender: Any) {
        
        //  let imagePicker = ImagePickerController()
        imagePicker.settings.selection.max = 10
        imagePicker.settings.theme.selectionStyle = .numbered
        imagePicker.settings.fetch.assets.supportedMediaTypes = [.image, .video]
        imagePicker.settings.selection.unselectOnReachingMax = true
        
        let start = Date()
        self.presentImagePicker(imagePicker, select: { (asset) in
            print("Selected: \(asset)")
            PHImageManager.default().requestImage(for: asset, targetSize: PHImageManagerMaximumSize, contentMode: .aspectFit, options: nil) { (image, info) in
                // Do something with image
                self.selctedImg.image = image
            }
        }, deselect: { (asset) in
            print("Deselected: \(asset)")
        }, cancel: { (assets) in
            print("Canceled with selections: \(assets)")
        }, finish: { (assets) in
            print("Finished with selections: \(assets)")
            
            
        }, completion: {
            let finish = Date()
            print(finish.timeIntervalSince(start))
            
            
        })
        
    }
    
    @IBAction func uploadServerBtnActn(_ sender: Any) {
        let alert = UIAlertController(title: "Alert!", message: "Uploading error...Please try again latter", preferredStyle: UIAlertController.Style.alert)
        
        // add an action (button)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        
        // show the alert
        self.present(alert, animated: true, completion: nil)
    }
    
}
