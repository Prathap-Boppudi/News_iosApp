//
//  NewsViewController.swift
//  NewsApp
//
//  Created by APPLE on 14/12/22.
//

import UIKit

class NewsViewController: UIViewController {
    
    @IBOutlet weak var newsTbl: UITableView!
    
    var model = NewsModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.title = "News Items"
        
        model.getNewFeedAPI()
        self.setUpData()
        
        let Dnib = UINib(nibName: "NewsTableViewCell", bundle: nil)
        newsTbl.register(Dnib, forCellReuseIdentifier: "NewsTableViewCell")
        
    }
    // MARK: - Custom methods...
    func setUpData()
    {
        self.model.ondidDataMethod = {
            
            DispatchQueue.main.async {
                self.newsTbl.delegate = self
                self.newsTbl.dataSource = self
                // self.newsTbl.separatorStyle = .none
                self.newsTbl.reloadData()
                self.newsTbl.rowHeight = UITableView.automaticDimension
                self.newsTbl.estimatedRowHeight = 400
            }
            
        }
    }
    
}
// MARK: - Table view Methods...
extension NewsViewController: UITableViewDelegate, UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.model.dataArray?.articles?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell =  tableView.dequeueReusableCell(withIdentifier: "NewsTableViewCell", for: indexPath) as! NewsTableViewCell
        
        cell.titleLbl.text = self.model.dataArray?.articles![indexPath.row].title
        cell.descLbl.text = self.model.dataArray?.articles![indexPath.row].description
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Row_Clicked")
        
    }
}
