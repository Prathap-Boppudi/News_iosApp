//
//  ViewController.swift
//  NewsApp
//
//  Created by APPLE on 14/12/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var fileUploadBtn: UIButton!
    @IBOutlet weak var newsBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // MARK: - Button events...
    @IBAction func newsBtnActn(_ sender: Any) {
        
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "NewsViewController") as! NewsViewController
        self.navigationController?.pushViewController(vc, animated: true)
        //  self.present(vc, animated: true)
    }
    @IBAction func fileUploadBtnActn(_ sender: Any) {
        
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "UploadViewController") as! UploadViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

