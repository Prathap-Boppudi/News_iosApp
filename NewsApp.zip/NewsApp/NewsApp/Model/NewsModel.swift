//
//  NewsModel.swift
//  NewsApp
//
//  Created by APPLE on 14/12/22.
//

import UIKit

class NewsModel: NSObject {
    
    var dataArray : newsResp?
    
    var ondidDataMethod: (() -> Void)?
    
    func getNewFeedAPI()
    {
        let url = URL(string:"https://newsapi.org/v2/top-headlines?country=in&apiKey=a2a991b1ce51435d87b966013b797f4b")!
        
        print(url)
        
        let request = NSMutableURLRequest(url: url as URL)
        
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { data, response, error -> Void in
            
            if let error = error {
                
                print("Unable to make an api call", error)
                
                return
                
            }
            
            do {
                
                let result = try JSONDecoder().decode(newsResp.self, from: data!)
                
                //   print(result.articles)
                
                if let coinsResponse = result as? newsResp {
                    
                    self.dataArray = coinsResponse
                    
                    self.ondidDataMethod?()
                }
                
                
            } catch { print(error) }
            
        }).resume()
        
    }
    
}

struct newsResp: Codable
{
    var totalResults : Int?
    var articles : [articals]?
    var status : String?
}

struct articals: Codable
{
    var title: String?
    var description : String?
    var content : String?
    
}
